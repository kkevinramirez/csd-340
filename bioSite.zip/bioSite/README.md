# bioSite
CSD 340 - BioSite Project
# BioSite

## Description
This project, **BioSite**, is part of the coursework for **CSD 340 Web Development with HTML and CSS**. It demonstrates the foundational concepts of web development, including creating multiple HTML pages, styling them with CSS, and linking them together to form a cohesive website.

## Contributors
- **Instructor**: John Woods
- **Student**: Kevin Ramirez

